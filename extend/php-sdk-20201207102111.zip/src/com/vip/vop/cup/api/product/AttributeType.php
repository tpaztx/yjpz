<?php


/*
* Copyright (c) 2008-2016 vip.com, All Rights Reserved.
*
* Powered by com.vip.osp.osp-idlc-2.5.11.
*
*/

namespace com\vip\vop\cup\api\product;
final class AttributeType{
	
	
	const NORMAL = 0;
	
	const TAG = 1;
	
	const SPECIAL = 2;
	
	static public $__names = array(
	
	0 => 'NORMAL',
	
	1 => 'TAG',
	
	2 => 'SPECIAL',
	
	);
}

?>