<?php


/*
* Copyright (c) 2008-2016 vip.com, All Rights Reserved.
*
* Powered by com.vip.osp.osp-idlc-2.5.11.
*
*/

namespace com\vip\vop\cup\api\product;
final class ProductType{
	
	
	const SPU = 0;
	
	const SKU = 1;
	
	static public $__names = array(
	
	0 => 'SPU',
	
	1 => 'SKU',
	
	);
}

?>