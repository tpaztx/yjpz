<?php


/*
* Copyright (c) 2008-2016 vip.com, All Rights Reserved.
*
* Powered by com.vip.osp.osp-idlc-2.5.11.
*
*/

namespace com\vip\vop\cup\api\product;
final class OperationMode{
	
	
	const ADD = 0;
	
	const UPDATE = 1;
	
	const DELETE = 2;
	
	static public $__names = array(
	
	0 => 'ADD',
	
	1 => 'UPDATE',
	
	2 => 'DELETE',
	
	);
}

?>