<?php


/*
* Copyright (c) 2008-2016 vip.com, All Rights Reserved.
*
* Powered by com.vip.osp.osp-idlc-2.5.11.
*
*/

namespace com\vip\vop\cup\api\product;
final class DataType{
	
	
	const TEXT = 0;
	
	const NUMERIC = 1;
	
	const OPTION = 2;
	
	const BUMBLE = 3;
	
	const PICTURE = 4;
	
	static public $__names = array(
	
	0 => 'TEXT',
	
	1 => 'NUMERIC',
	
	2 => 'OPTION',
	
	3 => 'BUMBLE',
	
	4 => 'PICTURE',
	
	);
}

?>