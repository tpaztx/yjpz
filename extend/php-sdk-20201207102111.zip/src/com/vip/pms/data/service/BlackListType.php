<?php


/*
* Copyright (c) 2008-2016 vip.com, All Rights Reserved.
*
* Powered by com.vip.osp.osp-idlc-2.5.11.
*
*/

namespace com\vip\pms\data\service;
final class BlackListType{
	
	
	const BRAND = 1;
	
	const BRAND_STORE_SN = 2;
	
	const CATEGORY_ID = 3;
	
	static public $__names = array(
	
	1 => 'BRAND',
	
	2 => 'BRAND_STORE_SN',
	
	3 => 'CATEGORY_ID',
	
	);
}

?>