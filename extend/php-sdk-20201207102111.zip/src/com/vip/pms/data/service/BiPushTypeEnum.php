<?php


/*
* Copyright (c) 2008-2016 vip.com, All Rights Reserved.
*
* Powered by com.vip.osp.osp-idlc-2.5.11.
*
*/

namespace com\vip\pms\data\service;
final class BiPushTypeEnum{
	
	
	const RiskBuygiftBlacklist = 1;
	
	static public $__names = array(
	
	1 => 'RiskBuygiftBlacklist',
	
	);
}

?>