<?php


/*
* Copyright (c) 2008-2016 vip.com, All Rights Reserved.
*
* Powered by com.vip.osp.osp-idlc-2.5.11.
*
*/

namespace com\vip\pms\data\service;
final class SyncType{
	
	
	const ADD = 0;
	
	const DELETE = 1;
	
	static public $__names = array(
	
	0 => 'ADD',
	
	1 => 'DELETE',
	
	);
}

?>