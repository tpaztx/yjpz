<?php


/*
* Copyright (c) 2008-2016 vip.com, All Rights Reserved.
*
* Powered by com.vip.osp.osp-idlc-2.5.11.
*
*/

namespace com\vip\pms\data\enums;
final class SupportPrepayFlag{
	
	
	const SUPPORT_PREPAY = 1;
	
	const NON_SUPPORT_PREPAY = 0;
	
	static public $__names = array(
	
	1 => 'SUPPORT_PREPAY',
	
	0 => 'NON_SUPPORT_PREPAY',
	
	);
}

?>