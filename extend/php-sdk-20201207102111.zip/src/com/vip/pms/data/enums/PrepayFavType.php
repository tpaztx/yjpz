<?php


/*
* Copyright (c) 2008-2016 vip.com, All Rights Reserved.
*
* Powered by com.vip.osp.osp-idlc-2.5.11.
*
*/

namespace com\vip\pms\data\enums;
final class PrepayFavType{
	
	
	const RATIO = 1;
	
	const CASH = 2;
	
	const DISCOUNT = 3;
	
	static public $__names = array(
	
	1 => 'RATIO',
	
	2 => 'CASH',
	
	3 => 'DISCOUNT',
	
	);
}

?>