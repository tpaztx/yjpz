<?php


/*
* Copyright (c) 2008-2016 vip.com, All Rights Reserved.
*
* Powered by com.vip.osp.osp-idlc-2.5.11.
*
*/

namespace com\vip\pms\data\enums;
final class GroupBuyingFlag{
	
	
	const GROUP_BUYING = 1;
	
	const NON_GROUP_BUYING = 0;
	
	static public $__names = array(
	
	1 => 'GROUP_BUYING',
	
	0 => 'NON_GROUP_BUYING',
	
	);
}

?>