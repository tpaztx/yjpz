<?php


/*
* Copyright (c) 2008-2016 vip.com, All Rights Reserved.
*
* Powered by com.vip.osp.osp-idlc-2.5.11.
*
*/

namespace com\vip\adp\api\open\service;
final class VipLinkTypeEnum{
	
	
	const ILLEGAL_LINK = -1;
	
	const NOT_VIPSHOP_LINK = 0;
	
	const GOODS = 1;
	
	const BRAND = 2;
	
	const OTHER = 9;
	
	static public $__names = array(
	
	-1 => 'ILLEGAL_LINK',
	
	0 => 'NOT_VIPSHOP_LINK',
	
	1 => 'GOODS',
	
	2 => 'BRAND',
	
	9 => 'OTHER',
	
	);
}

?>