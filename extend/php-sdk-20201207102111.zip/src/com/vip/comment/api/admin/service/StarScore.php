<?php


/*
* Copyright (c) 2008-2016 vip.com, All Rights Reserved.
*
* Powered by com.vip.osp.osp-idlc-2.5.11.
*
*/

namespace com\vip\comment\api\admin\service;
final class StarScore{
	
	
	const OneStart = 1;
	
	const TwoStarts = 2;
	
	const ThreeStarts = 3;
	
	const FourStarts = 4;
	
	const FiveStarts = 5;
	
	static public $__names = array(
	
	1 => 'OneStart',
	
	2 => 'TwoStarts',
	
	3 => 'ThreeStarts',
	
	4 => 'FourStarts',
	
	5 => 'FiveStarts',
	
	);
}

?>